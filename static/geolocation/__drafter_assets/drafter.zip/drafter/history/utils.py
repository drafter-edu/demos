"""
Utility functions for the Drafter history module.
"""

import html
import json
import base64
import io
from dataclasses import fields, is_dataclass
from typing import Any

from drafter.components.utilities.image_support import HAS_PILLOW, PILImage
from drafter.helpers.utils import is_pyodide, is_skulpt


TOO_LONG_VALUE_THRESHOLD = 256


def make_value_expandable(value):
    """
    Wraps long string values in an expandable span for better display.

    Args:
        value: The value to potentially make expandable

    Returns:
        HTML string with expandable wrapper if needed
    """
    if isinstance(value, str) and len(value) > TOO_LONG_VALUE_THRESHOLD:
        return f"<span class='expandable'>{value}</span>"
    return value


def value_to_html(value):
    """
    Converts a value to an HTML-safe representation.

    Args:
        value: The value to convert

    Returns:
        HTML-escaped string representation
    """
    return make_value_expandable(html.escape(repr(value)))


def is_generator(iterable):
    """
    Checks if an object is a generator (has __iter__ but not __len__).

    Args:
        iterable: The object to check

    Returns:
        True if it's a generator, False otherwise
    """
    return hasattr(iterable, "__iter__") and not hasattr(iterable, "__len__")


def image_to_bytes(value):
    if is_skulpt():
        with io.BytesIO() as output:
            value.save(output, format="PNG")
            return output.getvalue()
    elif is_pyodide():
        with io.BytesIO() as output:
            value.save(output, format="PNG")
            return output.getvalue()
    else:
        raise RuntimeError("Unsupported environment for image_to_bytes")


def repr_pil_image(value):
    """
    Creates an HTML representation of a PIL Image.

    Args:
        value: A PIL Image object

    Returns:
        HTML img tag string
    """
    filename = value.filename if hasattr(value, "filename") else None
    if not filename:
        # Encode image as base64 data URI
        # image_data = io.BytesIO()
        # value.save(image_data, format="PNG")
        # image_data.seek(0)
        # encoded = base64.b64encode(image_data.getvalue()).decode("latin1")
        # image_src = f"data:image/png;base64,{encoded}"
        if not value:
            return "<strong>Empty Image</strong>"
        try:
            image_data = base64.b64encode(image_to_bytes(value)).decode("latin1")
            image_src = f"data:image/png;base64,{image_data}"
            escaped_data = json.dumps(image_data)
            full_call = f'Image.open(io.BytesIO(base64.b64decode({escaped_data}.encode("latin1"))))'
            return f"<img src='{image_src}' alt='PIL Image' />"
        except Exception as e:
            return f"<strong>Error displaying image: {e}</strong>"
    else:
        # Reference by filename
        return f"<img src='{filename}' alt='Image.open({filename!r})' />"


def safe_repr(value: Any, handled=None, escape=True):
    """
    Creates a safe HTML representation of a value, handling circular references.

    Args:
        value: The value to represent
        handled: Set of already-handled object IDs (for circular reference detection)
        escape: Whether to HTML-escape the representation

    Returns:
        HTML-safe string representation
    """
    obj_id = id(value)
    if handled is None:
        handled = set()
    else:
        handled = set(handled)
    if obj_id in handled:
        return "<strong>Circular Reference</strong>"
    if isinstance(
        value, (int, float, bool, type(None), str, bytes, complex, bytearray)
    ):
        if escape:
            return make_value_expandable(html.escape(repr(value)))
        return make_value_expandable(repr(value))
    if isinstance(value, list):
        handled.add(obj_id)
        return f"[{', '.join(safe_repr(v, handled, escape) for v in value)}]"
    if isinstance(value, dict):
        handled.add(obj_id)
        return f"{{{', '.join(f'{safe_repr(k, handled, escape)}: {safe_repr(v, handled, escape)}' for k, v in value.items())}}}"
    if is_dataclass(value):
        handled.add(obj_id)
        fields_repr = ", ".join(
            f"{f.name}={safe_repr(getattr(value, f.name), handled, escape)}"
            for f in fields(value)
        )
        return f"{value.__class__.__name__}({fields_repr})"  # type: ignore
    if isinstance(value, set):
        handled.add(obj_id)
        return f"{{{', '.join(safe_repr(v, handled, escape) for v in value)}}}"
    if isinstance(value, tuple):
        handled.add(obj_id)
        return f"({', '.join(safe_repr(v, handled, escape) for v in value)})"
    if isinstance(
        value,
        (
            frozenset,
            range,
        ),
    ):
        handled.add(obj_id)
        args_repr = ", ".join(safe_repr(v, handled, escape) for v in value)
        return f"{value.__class__.__name__}({{{args_repr}}})"

    if HAS_PILLOW and isinstance(value, PILImage.Image):
        return repr_pil_image(value)

    # Fallback for other types
    if escape:
        return make_value_expandable(html.escape(repr(value)))
    return make_value_expandable(repr(value))
